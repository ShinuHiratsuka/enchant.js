var img=[
'img/back.png',
'img/end_all.png',
'img/help.png',
'img/ready_all.png',
'img/start.png',
'img/title.png',
'img/font0.png',
'img/oboete.png',
'img/touch.png',
'img/0.png',
'img/1.png',
'img/2.png',
'img/3.png'
];


var STATUS_AUTOPLAY=0;
var STATUS_PLAY=1;
var SWITCH_TIME = 10;


