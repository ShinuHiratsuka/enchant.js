var playScene = enchant.Class.create(enchant.Scene, {
	initialize: function(stage, score) {
		var game = enchant.Game.instance;
		enchant.Scene.call(this);
		game.setCentering(this);
		this.time = 0;

		this.go_f = 0;
		this.gs_f = 0;
		this.max_combo = 0;
		this.combo = 0;
		this.answer = [];
		this.sleep=SWITCH_TIME;
		
		this.oboete = new Sprite(320,75);
		this.oboete.image = game.assets['img/oboete.png'];
		this.oboete.y = 10;
		this.oboete.visible = false;
		this.addChild(this.oboete);
		this.touch = new Sprite(320,75);
		this.touch.image = game.assets['img/touch.png'];
		this.touch.y = 10;
		this.touch.visible = false;
		this.addChild(this.touch);
		
		this.level = 0;
		this.status = STATUS_AUTOPLAY;
		
		this.simon = new Simon();
		this.addChild(this.simon);
		
		this.statusframe = new StatusFrame(this.stage);
		this.addChild(this.statusframe);
		this.wait_massage = new WaitMessage();
		this.is_finish = false;

		this.mt=new MutableText(100,96+144,300);
		this.mt.setText('LEVEL 1');
		this.addChild(this.mt);

		this.ready = new Ready();
		this.addChild(this.ready);
		
		this.startAutoPlay();
	},
	onenterframe:function(){
		if (this.go_f != 1 || this.is_finish == true) return;

		if (this.status == STATUS_AUTOPLAY){
			this.touch.visible=false;
			this.oboete.visible = true;
			this.sleep--;
			if (this.sleep > 5) {
				return;
			}else if (this.sleep > 0){
				for (i=0;i<4;i++){
					this.simon.p[i].sw('off');
				}
				return;
			}else{
				this.playno++;
			}
			
			for (i=0;i<4;i++){
				this.simon.p[i].sw('off');
			}
			
			if (this.playno < this.answer.length){
				this.simon.p[this.answer[this.playno]].sw('on');
				this.sleep=SWITCH_TIME;
				return;
			}else{
				this.startPlay();
			}
		}else if (this.status == STATUS_PLAY){
			this.touch.visible=true;
			this.oboete.visible = false;
			
			if (this.simon.no == -1) return;
			
			if (this.simon.no == this.answer[this.playno]){
				this.playno++;
				this.simon.no=-1;
			}else{
				this.endGame();
			}
			if (this.playno >= this.answer.length){
				this.sleep=SWITCH_TIME;
				this.startAutoPlay();
				return;
			}
		}

	},
	startAutoPlay:function(){
		
		this.level++;
		this.mt.setText('LEVEL '+this.level);
		this.playno = -1;
		this.answer.push(parseInt(Math.random()*4));
		
		this.status = STATUS_AUTOPLAY;
	},
	startPlay:function(){
		this.playno=0;
	
		this.status = STATUS_PLAY;
	},
	endGame:function(){
		this.setClose();
	},
	enterframeAction: function(e) {
		if (this.time < 36) {
			this.time++;
		} else {
			this.removeChild(this.wait_message);
			this.removeEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
			game.replaceScene(new endScene(this.level*UNIT_SCORE, this.level));
		}
	},
	startTimer: function(idx) {
		this.takebuttons[idx].setTakeEnable();
	},
	stopTimer: function(idx) {
		score = this.visitors[idx][0].checkOrder(this.table.getToppingFlags());
		this.statusframe.addScore(score);
		this.takebuttons[idx].unsetTakeEnable();
	},
	setClose: function() {
		this.time = 0;
		this.is_finish = true;
		this.addChild(this.wait_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	}
});

var Simon = enchant.Class.create(enchant.Group, {
	initialize:function(){
		Group.call(this);
		
		this.no=-1;
		
		this.p=[];
		for(i=0;i<4;i++){
			s = new Part(i);
			this.p.push(s);
			this.addChild(s);
		}
	}
});

var Part = enchant.Class.create(enchant.Sprite, {
	initialize:function(no){
		Sprite.call(this,140,140);
		this.x = 10+(i%2)*160;
		this.y = 96+parseInt(i/2)*160;
		this.image = game.assets['img/'+i+'.png'];
		this.frame = 0;
		this.no=no;
	},
	ontouchstart:function(e){
		this.frame = 1;
		this.parentNode.no=this.no;
	},
	ontouchend:function(e){
		this.frame =0;
		this.parentNode.no=-1;
	},
	sw:function(s){
		if (s == 'on'){
			this.frame = 1;
		}else{
			this.frame = 0;
		
		}
	}
});












var StatusFrame = enchant.Class.create(enchant.Group, {
	initialize: function(stage) {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.stage = stage;
	}
});
var WaitMessage = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.end_massage = new Sprite(320, 416);
		this.end_massage._element.style.zIndex = 6;
		this.end_massage.image = game.assets['img/end_all.png'];
		this.end_massage.y = 30;
		this.addChild(this.end_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframe);
	},
	enterframe: function() {
		if (this.end_massage.frame != 29) {
			this.end_massage.frame++;
		}
	}
});
var Ready = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.alpha = new Sprite(game.width, game.height);
		this.alpha.opacity = 0.75;
		this.alpha.backgroundColor = "#000000";
		this.addChild(this.alpha);
		this.start_name = new Label("touch to the<br/>game start...");
		this.start_name.width = 320;
		this.start_name.height = 416;
		this.start_name.y = 250;
		this.start_name.color = "#FFFFFF";
		this.start_name._element.style.textAlign = "center";
		this.start_name._element.style.zIndex = 6;
		this.start_name._element.style.fontSize = "16pt";
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.addChild(this.start_name);
		this.stage_name = new Sprite(320, 416);
		this.stage_name.image = game.assets['img/ready_all.png'];
		this.addChild(this.stage_name);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	},
	touchAction: function(e) {
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.parentNode.gs_f = 1;
		this.stage_name.frame = 8;
		this.removeEventListener(enchant.Event.TOUCH_START, this.touchAction);
	},
	enterframeAction: function() {
		if (this.parentNode.gs_f == 1) {
			if (this.cnt >= 8) {
				this.parentNode.go_f = 1;
				this.parentNode.removeChild(this);
			} else {
				this.cnt++;
			}
		} else {
			if (this.stage_name.frame < 6) {
				this.stage_name.frame++;
			} else {
				this.cnt++;
				if (this.cnt >= 5) {
					this.cnt = 0;
					if (this.stage_name.frame == 7) {
						this.stage_name.frame = 6;
					} else {
						this.stage_name.frame = 7;
					}
				}
				if (this.start_name.opacity != 1) {
					this.start_name.opacity = 1;
					var startBG = new Sprite(320, 416);
					this.addEventListener(enchant.Event.TOUCH_START, this.touchAction);
					this.addChild(startBG);
				}
			}
		}
	}
});