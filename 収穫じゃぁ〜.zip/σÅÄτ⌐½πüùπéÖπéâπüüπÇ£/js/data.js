var img=[
'img/back.png',
'img/bg.jpg',
'img/end_all.png',
'img/help.png',
'img/ready_all.png',
'img/start.png',
'img/time_bar.png',
'img/time_bar2.png',
'img/title.png',
'img/font0.png',
'img/farmer.png',
'img/harvest.png',
'img/exp.png'
];
var FARMER_INIT_NUM=5;
var BLOCK_NORMAL=7;
var BLOCK_STAGE1=2;
var BLOCK_STAGE2=3;
var BLOCK_STAGE3=4;
var BLOCK_FINAL_STAGE=0;
var MAP_WIDTH=9;
var MAP_HEIGHT=13;

