var img=[
'img/back.png',
'img/end_all.png',
'img/help.png',
'img/ready_all.png',
'img/start.png',
'img/title.png',
'img/map2.png',
'img/font0.png',
'img/map2.png'
];
var BLOCK_NON=13;
var BLOCK_NORMAL=1;
var BLOCK_IRON=2;
var BLOCK_COIN=9;
var BLOCK_WATER=18;
var MAP_WIDTH=14;
var MAP_HEIGHT=13;

