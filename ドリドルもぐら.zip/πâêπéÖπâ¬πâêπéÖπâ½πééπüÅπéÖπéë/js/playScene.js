var playScene = enchant.Class.create(enchant.Scene, {
	initialize: function(stage, score) {
		var game = enchant.Game.instance;
		enchant.Scene.call(this);
		game.setCentering(this);
		this.time = 0;

		this.exp = new Array();
		
		this.map = new ExMap(32,32);
		this.map.image = game.assets['img/map2.png'];
		this.addChild(this.map);
		
		this.player = new Player(100,160);
		this.addChild(this.player);
		
		this.go_f = 0;
		this.gs_f = 0;
		this.max_combo = 0;
		this.combo = 0;
		
		this.statusframe = new StatusFrame(this.stage);
		this.addChild(this.statusframe);
		this.wait_massage = new WaitMessage();
		this.is_finish = false;
		
		this.score=new ScoreLabel(10,10);
		this.score.score=0;
		this.addChild(this.score);

		this.ready = new Ready();
		this.addChild(this.ready);

		this.pad = new Pad();
		this.pad.moveTo(0,316);
		//this.addChild(this.pad);
		
	},
	ontouchstart:function(e){
		if (this.go_f != 1 || this.is_finish == true) return;
		
		var game = enchant.Game.instance;
		var pos = this._element.getBoundingClientRect();
		x=Math.floor(e.x - ((pos.left) / game.scale));
		y=Math.floor(e.y - ((pos.top) / game.scale));
		
		if (y < 416/2){
			game.input.up=true;
		}else{
			game.input.down=true;
		}
	},
	ontouchend:function(e){
		if (this.go_f != 1 || this.is_finish == true) return;
		var game = enchant.Game.instance;
		var pos = this._element.getBoundingClientRect();
		x=Math.floor(e.x - ((pos.left) / game.scale));
		y=Math.floor(e.y - ((pos.top) / game.scale));
		
		game.input.up=false;
		game.input.down=false;
	},
	onenterframe:function(){
		if (this.go_f != 1 || this.is_finish == true) return;
		
		this.x = Math.random()*3-Math.random()*3;
		this.y = Math.random()*3-Math.random()*3;
		
		c = this.map.checkTile(this.player.x-this.map.x, this.player.y);
		if (c !==BLOCK_WATER){
			var game = enchant.Game.instance;
			var input = game.input;
			if (input.up) {
				this.player.y-=16;
				if (this.player.y < 0) this.player.y =0;
			}
			if (input.down) {
				this.player.y+=16;
				if (this.player.y > 416-32) this.player.y = 416-32;
			}
		}
		
		if (c === BLOCK_IRON){
			this.setClose();
			return;
			
		}

		if (c !== BLOCK_NORMAL) {
			if (c ===BLOCK_NON && c ===BLOCK_WATER){
				
			}else if (c ===BLOCK_COIN){
				this.score.score+=UNIT_SCORE;
				this.map.setTile(this.player.x-this.map.x, this.player.y, BLOCK_NON);
			}
		}else{
			ex = new Explode(this.player.x, this.player.y);
			this.exp.push(ex);
			this.addChild(ex);
			this.map.setTile(this.player.x-this.map.x, this.player.y, BLOCK_NON);
		}
		this.map.scroll(parseInt(-16));

	},
	enterframeAction: function(e) {
		if (this.time < 36) {
			this.time++;
		} else {
			this.removeChild(this.wait_message);
			this.removeEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
			game.replaceScene(new endScene(this.score.score, this.max_combo));
		}
	},
	startTimer: function(idx) {
		this.takebuttons[idx].setTakeEnable();
	},
	stopTimer: function(idx) {
		score = this.visitors[idx][0].checkOrder(this.table.getToppingFlags());
		this.statusframe.addScore(score);
		this.takebuttons[idx].unsetTakeEnable();
	},
	setClose: function() {
		this.time = 0;
		this.is_finish = true;
		this.addChild(this.wait_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	}
});
var StatusFrame = enchant.Class.create(enchant.Group, {
	initialize: function(stage) {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.stage = stage;
	}
});

var ExMap = enchant.Class.create(enchant.Map, {
	initialize:function(tileWidth,tileHeight){
		Map.call(this,tileWidth,tileHeight);
		this.scrolltimes=0;
		var data=[[]];
		this.preblock = -1;
		this.prepos=-1;
		for (i=0;i<MAP_HEIGHT;i++){
			data[i]=[];
			for (j=0;j<MAP_WIDTH;j++){
				data[i][j]=BLOCK_NORMAL;
			}
		}
		this.loadData(data);
	},
	setTile:function (x,y,tile){
		if (x < 0 || this.width <= x || y < 0 || this.height <= y) {
			return false;
	    }
		var width = this._image.width;
		var height = this._image.height;
		var tileWidth = this._tileWidth || width;
		var tileHeight = this._tileHeight || height;
		x = x / tileWidth | 0;
		y = y / tileHeight | 0;
		var data = this._data[0];
		data[y][x]=tile;
		this._data[0]=data;
		this._dirty = true;

		return true;
	},
	scroll:function(x){
		this.x +=x;
		this.scrolltimes++;
		if (this.x < -32 *3){
			for (i=0;i<this._data[0].length;i++){
				this._data[0][i].shift();
				this._data[0][i].shift();
				this._data[0][i].shift();
				this._data[0][i].push(BLOCK_NORMAL);
				this._data[0][i].push(BLOCK_NORMAL);
				this._data[0][i].push(BLOCK_NORMAL);
			}
			r = Math.random()*100;
			if (0 < r && r < 30){
				this.preblock = BLOCK_IRON;
				n = parseInt(Math.random()*(this.scrolltimes/100))+1;
				for (i=0;i<n;i++){
					y = parseInt(Math.random()*7);
					this._data[0][y][MAP_WIDTH-1]=BLOCK_IRON;
					this._data[0][y][MAP_WIDTH-2]=BLOCK_IRON;
					this._data[0][y][MAP_WIDTH-3]=BLOCK_IRON;
					this._data[0][y+1][MAP_WIDTH-1]=BLOCK_IRON;
					this._data[0][y+1][MAP_WIDTH-2]=BLOCK_IRON;
					this._data[0][y+1][MAP_WIDTH-3]=BLOCK_IRON;
					this._data[0][y+2][MAP_WIDTH-1]=BLOCK_IRON;
					this._data[0][y+2][MAP_WIDTH-2]=BLOCK_IRON;
					this._data[0][y+2][MAP_WIDTH-3]=BLOCK_IRON;
				}
				
				this.prepos = -1;
			}
			if (this.preblock == BLOCK_WATER) max=80;
			else max = 50;
			if (30 < r && r < max){
				y = parseInt(Math.random()*7);
				if (this.prepos != -1) y -= parseInt(Math.random()*3);
				if (y >= 0){
					this._data[0][y][MAP_WIDTH-1]=BLOCK_WATER;
					this._data[0][y][MAP_WIDTH-2]=BLOCK_WATER;
					this._data[0][y][MAP_WIDTH-3]=BLOCK_WATER;
					this.preblock = BLOCK_WATER;
					this.prepos = y;
				}
			}
			if (50 < r && r < 75){
				y = parseInt(Math.random()*7);
				this.preblock = BLOCK_COIN;
				this.prepos = y;
				this._data[0][y][MAP_WIDTH-1]=BLOCK_NON;
				this._data[0][y][MAP_WIDTH-2]=BLOCK_NON;
				this._data[0][y][MAP_WIDTH-3]=BLOCK_NON;
				this._data[0][y+1][MAP_WIDTH-1]=BLOCK_NON;
				this._data[0][y+1][MAP_WIDTH-2]=BLOCK_COIN;
				this._data[0][y+1][MAP_WIDTH-3]=BLOCK_NON;
				this._data[0][y+2][MAP_WIDTH-1]=BLOCK_NON;
				this._data[0][y+2][MAP_WIDTH-2]=BLOCK_NON;
				this._data[0][y+2][MAP_WIDTH-3]=BLOCK_NON;
				this.prepos = -1;
			}
			this.x +=32*3;
			this._dirty = true;
		}

	}
});

var Player = enchant.Class.create(enchant.Sprite, {
	initialize: function(x, y){
		Sprite.call(this, 32, 32);
		this.x = x;
		this.y = y;
		this.image = game.assets['img/map2.png'];
		this.frame = 11;
	}
});

var Explode = enchant.Class.create(enchant.Group, {
	initialize: function (x, y){
		enchant.Group.call(this);
		this.x = x;
		this.y = y;
		this.piece = [];
		var game = enchant.Game.instance;
		
		for (i=0;i<4;i++){
			b = new Sprite(16,16);
			b.opacity = 1;
			b.image=game.assets['img/map2.png'];
			if (i <2){
				b.frame = 6+i;
				b.x = i*16+Math.random()*16-Math.random()*16;
				b.y = 0+Math.random()*16-Math.random()*16;
				b.dx = -Math.random()*3+i*Math.random()*6;
				b.dy = -Math.random()*3;
			}else{
				b.frame = 22 + i;
				b.x = (i-2)*16+Math.random()*16-Math.random()*16;
				b.y = 16+Math.random()*16-Math.random()*16;
				b.dx = -Math.random()*3+(i-2)*Math.random()*6;
				b.dy = Math.random()*3;
			}
			b.onenterframe = function(){
				this.x += this.dx;
				this.y += this.dy;
				this.rotation += Math.random()*45;
				this.opacity *= 0.99;
				if (this.opacity >= 1) {
					delete this;
				}
			};
			this.piece.push(b);
			this.addChild(b);
		}
		this.del =0;
	},
	onenterframe:function(){
		if (this.age > 3){
			for (i=0;i<this.piece.length;i++){
				if (this.piece[i].opacity < 0.1){
					this.removeChild(this.piece[i]);
					this.piece.splice(i,1);
				}
			}
			if (this.piece.length == 0){
				this.del=1;
			}
		}
	}
});

var WaitMessage = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.end_massage = new Sprite(320, 416);
		this.end_massage._element.style.zIndex = 6;
		this.end_massage.image = game.assets['img/end_all.png'];
		this.end_massage.y = 30;
		this.addChild(this.end_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframe);
	},
	enterframe: function() {
		if (this.end_massage.frame != 29) {
			this.end_massage.frame++;
		}
	}
});
var Ready = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.alpha = new Sprite(game.width, game.height);
		this.alpha.opacity = 0.75;
		this.alpha.backgroundColor = "#000000";
		this.addChild(this.alpha);
		this.start_name = new Label("touch to the<br/>game start...");
		this.start_name.width = 320;
		this.start_name.height = 416;
		this.start_name.y = 250;
		this.start_name.color = "#FFFFFF";
		this.start_name._element.style.textAlign = "center";
		this.start_name._element.style.zIndex = 6;
		this.start_name._element.style.fontSize = "16pt";
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.addChild(this.start_name);
		this.stage_name = new Sprite(320, 416);
		this.stage_name.image = game.assets['img/ready_all.png'];
		this.addChild(this.stage_name);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	},
	touchAction: function(e) {
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.parentNode.gs_f = 1;
		this.stage_name.frame = 8;
		this.removeEventListener(enchant.Event.TOUCH_START, this.touchAction);
	},
	enterframeAction: function() {
		if (this.parentNode.gs_f == 1) {
			if (this.cnt >= 8) {
				this.parentNode.go_f = 1;
				this.parentNode.removeChild(this);
			} else {
				this.cnt++;
			}
		} else {
			if (this.stage_name.frame < 6) {
				this.stage_name.frame++;
			} else {
				this.cnt++;
				if (this.cnt >= 5) {
					this.cnt = 0;
					if (this.stage_name.frame == 7) {
						this.stage_name.frame = 6;
					} else {
						this.stage_name.frame = 7;
					}
				}
				if (this.start_name.opacity != 1) {
					this.start_name.opacity = 1;
					var startBG = new Sprite(320, 416);
					this.addEventListener(enchant.Event.TOUCH_START, this.touchAction);
					this.addChild(startBG);
				}
			}
		}
	}
});