var playScene = enchant.Class.create(enchant.Scene, {
	initialize: function(stage, score) {
		var game = enchant.Game.instance;
		enchant.Scene.call(this);
		game.setCentering(this);
		this.time = 0;
		
		this.bomb = new Array();
		this.shot = new Array();
		this.exp = new Array();
		
		bg = new Sprite(320,416);
		bg.image = game.assets['img/bg.jpg'];
		this.addChild(bg);
		
		this.map = new ExMap(32,32);
		this.map.image = game.assets['img/map2.png'];
		this.map.initCollision();
		this.addChild(this.map);
		
		this.player = new Player(4,this.map.getHeight(4));
		this.addChild(this.player);
		
		this.go_f = 0;
		this.gs_f = 0;
		this.max_combo = 0;
		this.combo = 0;
		this.score = 0;
		
		this.statusframe = new StatusFrame(this.stage);
		this.addChild(this.statusframe);
		this.wait_massage = new WaitMessage();
		this.is_finish = false;

		this.clock = new Clock();
		this.clock.x = 320-32;
		this.clock.y = 55;
		this.addChild(this.clock);
		this.ready = new Ready();
		this.addChild(this.ready);
	},
	onenterframe:function(){
		
		var pos = this._element.getBoundingClientRect();
		if (game.frame % 15 == 0){
			if (this.go_f != 1 || this.is_finish == true) return;

			max = Math.random()*2;
			for (i=0;i<max;i++){
				x = parseInt(Math.random()*9);
				b = new Bomb(x*32,parseInt(Math.random()*BLOCK_MAX));
				this.bomb.push(b);
				this.addChild(b);
			}
		}
		for (i=0;i<this.bomb.length;i++){
			if (this.map.checkTile(this.bomb[i].x+16, this.bomb[i].y+16)===this.bomb[i].type){
				this.bomb[i].del=1;
			}else if (this.map.checkTile(this.bomb[i].x+16, this.bomb[i].y+16)!==BLOCK_NON 
				&& this.bomb[i].y >= 0){
				this.bomb[i].del=1;
				ex = new Explode(this.bomb[i].x, this.bomb[i].y);
				this.addChild(ex);
				this.exp.push(ex);
				this.map.setTile(this.bomb[i].x+16, this.bomb[i].y+16, BLOCK_NON);
				
				if (this.combo > this.max_combo){
					this.max_combo=this.combo;
				}
				this.combo=0;
			}
			if (this.player.within(this.bomb[i], 24)){
				this.bomb[i].del=1;
				this.combo++;
				if (this.combo > 1) {
					l = new enchant.Label("COMBO "+this.combo+" !");
					l.x = this.bomb[i].x;
					l.y = this.bomb[i].y;
					l.onenterframe = function(){
						this.y--;
						this.opacity*=0.9;
						if (this.opacity<0.1) {
							delete this;
						}
					};
					this.color='gray';
					this.addChild(l);
				}
				this.score+=UNIT_SCORE*this.combo;
			}
		
			if (this.bomb[i].del == 1){
				this.removeChild(this.bomb[i]);
				this.bomb.splice(i,1);
			}
		}
		for (i=0;i<this.exp.length;i++){
			if (this.exp[i].del == 1){
				this.removeChild(this.exp[i]);
				this.exp.splice(i,1);
			}
		}
	},
	ontouchstart:function(e){
		if (this.go_f != 1 || this.is_finish == true) return;
		
		var pos = this._element.getBoundingClientRect();
		x=Math.floor(e.x - ((pos.left) / game.scale));
		y=Math.floor(e.y - ((pos.top) / game.scale));
		
		if (x < 320/2){
			this.player.posx--;
		}else{
			this.player.posx++;
		}
		if (this.player.posx < 0){
			this.player.posx=0;
		}else if (this.player.posx > 8){
			this.player.posx=8;
		}
		this.player.posy=this.map.getHeight(this.player.posx);
		this.player.move(this.player.posx,this.player.posy);

	},
	enterframeAction: function(e) {
		if (this.time < 36) {
			this.time++;
		} else {
			this.removeChild(this.wait_message);
			this.removeEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
			game.replaceScene(new endScene(this.score, this.max_combo));
		}
	},
	startTimer: function(idx) {
		this.takebuttons[idx].setTakeEnable();
	},
	stopTimer: function(idx) {
		score = this.visitors[idx][0].checkOrder(this.table.getToppingFlags());
		this.statusframe.addScore(score);
		this.takebuttons[idx].unsetTakeEnable();
	},
	setClose: function() {
		this.time = 0;
		this.is_finish = true;
		this.addChild(this.wait_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	}
});
var StatusFrame = enchant.Class.create(enchant.Group, {
	initialize: function(stage) {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.stage = stage;
	}
});

var ExMap = enchant.Class.create(enchant.Map, {
	initialize:function(tileWidth,tileHeight){
		Map.call(this,tileWidth,tileHeight);
	},
	setTile:function (x,y,tile){
		if (x < 0 || this.width <= x || y < 0 || this.height <= y) {
			return false;
	    }
		var width = this._image.width;
		var height = this._image.height;
		var tileWidth = this._tileWidth || width;
		var tileHeight = this._tileHeight || height;
		x = x / tileWidth | 0;
		y = y / tileHeight | 0;
		var data = this._data[0];
		data[y][x]=tile;
		this._data[0]=data;
		this._dirty = true;

		return true;
	},
	getTopBlock:function(x){
		for (j=0;j<13;j++){
			b=this.checkTile(x, j * 32);
			if (b!==BLOCK_NON){
				return b;
			}
		}
	},
	getHeight:function(x){
		for (j=12;j>0;j--){
			if (this.checkTile(x * 32, j * 32)==BLOCK_NON){
				return j;
				break;
			}
		}
	},
	initCollision:function(){
		var d = [
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[14, 14, 14, 14, 14, 14, 14, 14, 14],
			[ 6,  6,  6,  6,  6,  6,  6,  6,  6],
			[ 6,  6,  6,  6,  6,  6,  6,  6,  6]
			];
		this.loadData(d);
		max = Math.random()*20+10;
		
		for (i=0;i<max;i++){
			x = parseInt(Math.random()*9);
			for (j=10;j>0;j--){
				if (this.checkTile(x * 32, j * 32)==BLOCK_NON){
					this.setTile(x * 32, j * 32, parseInt(Math.random()*BLOCK_MAX));
					break;
				}
			}
		}
	},
});

function clone(obj){
    var F = function(){};
    F.prototype = obj;
    return new F;
}

var Bomb = enchant.Class.create(enchant.Sprite, {
		initialize: function(x,type){
			Sprite.call(this,32,32);
			this.x=x;
			this.y=-32;
			this.del = 0;
			this.image = game.assets['img/bomb.png'];
			this.type=type;
			this.frame=type;
		},
		onenterframe:function(){
			if (this.parentNode.map.getTopBlock(this.x)===this.type){
				this.frame=this.type;
			}else{
				this.frame=this.type+6;
			}
			this.y+=4;
			if (this.y > 416) this.del =1;
			this.rotation +=15;
		}
});

var Player = enchant.Class.create(enchant.Sprite, {
	initialize: function(x, y){
		Sprite.call(this, 32, 32);
		this.posx = x;
		this.x = x*32;
		this.posy = y;
		this.y = y*32;
		this.image = game.assets['img/map2.png'];
		this.frame = 13;
	},
	move:function (x ,y){
		this.posx = x;
		this.posy = y;
		this.x = x*32;
		this.y = y*32;
	}
});

var Explode = enchant.Class.create(enchant.Sprite, {
	initialize: function (x, y){
		enchant.Sprite.call(this, 64,64);
		var game = enchant.Game.instance;
		this.x = x-16;
		this.y = y-16;
		this.image = game.assets['img/exp.png'];
		this.frame = 0;
		this.del =0;
	},
	onenterframe: function(){
		this.frame++;
		if (this.frame >= 10){
			this.del = 1;
		}
	}
});

var WaitMessage = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.end_massage = new Sprite(320, 416);
		this.end_massage._element.style.zIndex = 6;
		this.end_massage.image = game.assets['img/end_all.png'];
		this.end_massage.y = 30;
		this.addChild(this.end_massage);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframe);
	},
	enterframe: function() {
		if (this.end_massage.frame != 29) {
			this.end_massage.frame++;
		}
	}
});
var Clock = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		var bg = new Sprite(31, 360);
		bg.image = game.assets['img/time_bar2.png'];
		this.addChild(bg);
		this.bar = new Sprite(31, 360);
		this.bar.image = game.assets['img/time_bar.png'];
		this.addChild(this.bar);
		this.time = new Label("TIME");
		this.time.x = -2;
		this.time.y = -38;
		this.time.color = "#222";
		this.time._element.style.fontSize = "12pt";
		this.time.width = 27;
		this.time._element.style.textAlign = "center";
		this.addChild(this.time);
		this.time_no = new Label(this.bar.height / 12);
		this.time.x = -2;
		this.time_no.y = -22;
		this.time_no._element.style.fontSize = "12pt";
		this.time_no.color = "#222";
		this.time_no.width = 27;
		this.time_no._element.style.textAlign = "center";
		this.addChild(this.time_no);
	},
	start: function() {
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	},
	stop: function() {
		this.removeEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	},
	enterframeAction: function() {
		if (Math.round((this.bar.height - 0.5) / 12) < 0) {
			this.removeEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
			this.parentNode.setClose();
		} else {
			this.bar.height -= 1;
			this.time_no.text = Math.round(this.bar.height / 12);
		}
	}
});
var Ready = enchant.Class.create(enchant.Group, {
	initialize: function() {
		enchant.Group.call(this);
		var game = enchant.Game.instance;
		this.alpha = new Sprite(game.width, game.height);
		this.alpha.opacity = 0.75;
		this.alpha.backgroundColor = "#000000";
		this.addChild(this.alpha);
		this.start_name = new Label("touch to the<br/>game start...");
		this.start_name.width = 320;
		this.start_name.height = 416;
		this.start_name.y = 250;
		this.start_name.color = "#FFFFFF";
		this.start_name._element.style.textAlign = "center";
		this.start_name._element.style.zIndex = 6;
		this.start_name._element.style.fontSize = "16pt";
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.addChild(this.start_name);
		this.stage_name = new Sprite(320, 416);
		this.stage_name.image = game.assets['img/ready_all.png'];
		this.addChild(this.stage_name);
		this.addEventListener(enchant.Event.ENTER_FRAME, this.enterframeAction);
	},
	touchAction: function(e) {
		this.start_name.opacity = 0;
		this.cnt = 0;
		this.parentNode.gs_f = 1;
		this.stage_name.frame = 8;
		this.removeEventListener(enchant.Event.TOUCH_START, this.touchAction);
	},
	enterframeAction: function() {
		if (this.parentNode.gs_f == 1) {
			if (this.cnt >= 8) {
				this.parentNode.clock.start();
				this.parentNode.go_f = 1;
				this.parentNode.removeChild(this);
			} else {
				this.cnt++;
			}
		} else {
			if (this.stage_name.frame < 6) {
				this.stage_name.frame++;
			} else {
				this.cnt++;
				if (this.cnt >= 5) {
					this.cnt = 0;
					if (this.stage_name.frame == 7) {
						this.stage_name.frame = 6;
					} else {
						this.stage_name.frame = 7;
					}
				}
				if (this.start_name.opacity != 1) {
					this.start_name.opacity = 1;
					var startBG = new Sprite(320, 416);
					this.addEventListener(enchant.Event.TOUCH_START, this.touchAction);
					this.addChild(startBG);
				}
			}
		}
	}
});