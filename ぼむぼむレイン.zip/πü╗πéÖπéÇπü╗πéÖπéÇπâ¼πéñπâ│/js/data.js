var img=[
'img/back.png',
'img/bg.jpg',
'img/end_all.png',
'img/help.png',
'img/ready_all.png',
'img/start.png',
'img/time_bar.png',
'img/time_bar2.png',
'img/title.png',
'img/map2.png',
'img/bomb.png',
'img/exp.png'
];

var BLOCK_NON=14;
var BLOCK_MAX=3;
